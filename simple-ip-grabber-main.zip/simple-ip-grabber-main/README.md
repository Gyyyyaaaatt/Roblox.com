# 🌐 Deadhook
<h2 align="center">⚡ Simple front-end IP grabber made in JavaScript & HTML!</h3>
<h4 align="center">🌟 If you enjoy this, star this repository and drop a follow! Thanks 😊</h3>
<br />

**⚠ WARNING:** This is ONLY for educational purposes.

<h2 align="left">- Features -</h3>

* `Extremely fast! `
* `Neat Embed which contains said victim's IP, ZIP, Country, Region, and Town. `
* `Frontend so no backend is required. Easy to host! `

# Usage
- **Step 1:** Replace `Replace this with your webhook` with your webhook! (Duh)
- **Step 2:** Save it & host it somewhere. (Any hosting service will work!)
- **Step 3:** Make someone click it! The message will pop up in your webhook instantly.
<br />

**Enjoy!** 😊
